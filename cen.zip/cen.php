<?php 
//update @2018
@set_time_limit(0); 
@error_reporting(E_ALL | E_NOTICE);
###################### enter your account info
$username = "YOURUSERNAME";
$password = "YOURPASSWORD";
######################
print "
 _____                            _____     _                  _             
/  __ \                          |  ___|   | |                | |            
| /  \/ ___ _ __  ___ _   _ ___  | |____  _| |_ _ __ __ _  ___| |_ ___  _ __ 
| |    / _ \ '_ \/ __| | | / __| |  __\ \/ / __| '__/ _` |/ __| __/ _ \| '__|
| \__/\  __/ | | \__ \ |_| \__ \ | |___>  <| |_| | | (_| | (__| || (_) | |   
 \____/\___|_| |_|___/\__, |___/ \____/_/\_\\__|_|  \__,_|\___|\__\___/|_|   
                       __/ |                                                 
                      |___/                                                  


";
echo"==========================================================\n".
	 "	* version => 2
	 * Coded By LNT
	* https://www.facebook.com/groups/hackteach.org/
	* Greats to : Cold z3ro & Ht team                 \n".
     "==========================================================\n";
echo"\r\n[#] Enter dork --> ";
$dork = trim(fgets(STDIN));
if (empty ($dork)) die ("Wrong Setting.");
		
		flush ();
		$bad = array_merge(
        array_map('chr', range(0,31)),
        array("<", ">", ":", '"', "/", "\\", "|", "?", "*"));
$filename = str_replace($bad, "", $dork);
					

		if(login()==true)
	{
		$pages = totalfound();
		echo  "Total Pages: ".$pages."\n";
		file_put_contents($GLOBALS['filename'].'.txt',$GLOBALS['filename']."\n", FILE_APPEND);
		for ($i = 0; $i <= $pages; $i++)
		{
			search($i);
			if($i =="200000")
			{
				$lines = file($GLOBALS['filename'].'.txt');
				$lines = array_unique($lines);
				file_put_contents($GLOBALS['filename'].'.txt', implode($lines));
				die("finished");
			}
		}
		echo " End .."; 
		$lines = file($GLOBALS['filename'].'.txt');
		$lines = array_unique($lines);
		file_put_contents($GLOBALS['filename'].'.txt', implode($lines));

	}else{
		die ("Login Error: check your login information lines 6&7 OR CONTACT WITH US");
	}

function search($do)
{
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, 'https://censys.io/ipv4/_search?q='.$GLOBALS['dork'].'&page='.$do);
	curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE );
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION,true);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded', 
	'Referer: https://censys.io/login', 
	'User-Agent: Mozilla/5.0 (Windows NT 6.1; rv:55.0) Gecko/20100101 Firefox/55.0'));
	curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
	curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
	curl_setopt($ch, CURLOPT_HEADER, FALSE );
	$rets = curl_exec($ch);
if(preg_match_all('/[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\:[0-9]{1,5}/', $rets, $match) or preg_match_all('/[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}/', $rets, $match))
	{
		foreach($match as $key => $ips)
		{
			foreach($ips as $key => $ip)
			{
				file_put_contents($GLOBALS['filename'].'.txt', trim($ip) ."\n", FILE_APPEND);
			}
		}
	}
}

							function totalfound()
						{
							$ch = curl_init();
							curl_setopt($ch, CURLOPT_URL, 'https://censys.io/ipv4/_search?q='.$GLOBALS['dork']);
							curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
							curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
							curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE );
							curl_setopt($ch, CURLOPT_FOLLOWLOCATION,true);
							curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded', 
							'Referer:https://censys.io/login', 
							'User-Agent: Mozilla/5.0 (Windows NT 6.1; rv:55.0) Gecko/20100101 Firefox/55.0'));
							curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
							curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
							curl_setopt($ch, CURLOPT_HEADER, FALSE );
							$rets = curl_exec($ch);
							preg_match('#Time: (.*?)
        </span>#i',$rets,$times);
							$time = $times[1];
							echo  "Search Time: ".$time."\n";
							preg_match('#Results: (.*?)
        </span>#i',$rets,$Results);
							
							$Result = $Results[1];
							echo  "Total Results: ".$Result."\n";
							preg_match('#Page: 1/(.*?)
        </span>#i',$rets,$spoof);
							$Pages = $spoof[1];
							
							
							return(trim(str_replace(',','',$Pages)));
						}
	function login()
	{		global $cookies;
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, "https://censys.io/login");
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
			curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE );
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION,true);
			$headers = array();
			$headers[] = "Accept-Encoding: gzip, deflate, br";
			$headers[] = "Accept-Language: fr-FR,fr;q=0.9,en-US;q=0.8,en;q=0.7";
			$headers[] = "Upgrade-Insecure-Requests: 1";
			$headers[] = "User-Agent: Mozilla/5.0 (Windows NT 6.1; rv:55.0) Gecko/20100101 Firefox/55.0";
			$headers[] = "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8";
			$headers[] = "Authority: censys.io";
			curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
			curl_setopt($ch, CURLOPT_HEADER, TRUE);
			curl_setopt($ch, CURLOPT_HEADERFUNCTION, "GetmyCookies");
			$result = curl_exec($ch);
			if (curl_errno($ch)) {
				echo 'Error:' . curl_error($ch);
			}
			preg_match('#censys.io.beaker.session.id=(.+)#i',$cookies[0][0],$session);
			 $sessionId=$session[1];

			 
						preg_match('#<input type="hidden" name="csrf_token" value="(.*?)">#i',$result,$tokens);
						$scrf =$tokens[1];
								$ch = curl_init();

								curl_setopt($ch, CURLOPT_URL, "https://censys.io/login");
								curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
								curl_setopt($ch, CURLOPT_POSTFIELDS, "csrf_token=".$scrf."&came_from=%2F&login=".$GLOBALS['username']."&password=".$GLOBALS['password']."");
								curl_setopt($ch, CURLOPT_POST, 1);
								curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');

								$headers = array();
								$headers[] = "Cookie: censys.io.beaker.session.id=".$sessionId."";
								$headers[] = "Origin: https://censys.io";
								$headers[] = "Accept-Encoding: gzip, deflate, br";
								$headers[] = "Accept-Language: fr-FR,fr;q=0.9,en-US;q=0.8,en;q=0.7";
								$headers[] = "Upgrade-Insecure-Requests: 1";
								$headers[] = "User-Agent: Mozilla/5.0 (Windows NT 6.1; rv:55.0) Gecko/20100101 Firefox/55.0";
								$headers[] = "Content-Type: application/x-www-form-urlencoded";
								$headers[] = "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8";
								$headers[] = "Cache-Control: max-age=0";
								$headers[] = "Authority: censys.io";
								$headers[] = "Referer: https://censys.io/login";
								curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
								curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
								curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

								$result = curl_exec($ch);
								if (curl_errno($ch)) {
									echo 'Error:' . curl_error($ch);
								}
									if(preg_match("/redirected/i", $result))
														{
															return true;
														}
}

	
	function GetmyCookies($ch5, $headerLine) {
    global $cookies;
    if (preg_match('/^Set-Cookie:\s*([^;]*)/mi', $headerLine, $cookie) == 1)
        $cookies[] = $cookie;
    return strlen($headerLine); 
}
@unlink("cookie.txt");
?>