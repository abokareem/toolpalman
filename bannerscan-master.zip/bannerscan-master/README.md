bannerscan
==========

C段Banner与路径扫描

Require:
Python2.6+
requests

Update[@le4f]:
原代码上加入部分路径

more:
http://x0day.me/archives/bannerscan-py.html
